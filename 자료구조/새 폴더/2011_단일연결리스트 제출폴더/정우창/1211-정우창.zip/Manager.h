#ifndef _MANAGER_H_
#define _MANAGER_H_
#include "Mylist.h"

void manager_init();
void Insert();
void Printall();
NODE * _Search(char ch);
void Search();
void Modify();
void Del();

#endif /*_MANAGER_H_*/