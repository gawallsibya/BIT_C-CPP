//app.h
#ifndef _APP_H_
#define _APP_H_

void init();
void menu();
void run();
void Exit();

#endif /*_APP_H_*/