#include"Mylist.h"

void insert(LIST _list);
void printall(LIST list);
NODE* search(char ch);
void updata();

void motify();
void del(LIST *p);