#include"Mylist.h"
#include"std.h"
void mylist_init(LIST *p)
{
	p->head	= NULL;
	p->tail	= NULL;
	p->count	= 0;
}
void mylist_push_front(LIST *p,NODE *newnode)
{	
	if( p->head == NULL)
	{
		p->head = newnode;
		p->tail = newnode;
		p->count++;
	}
	else
	{
		newnode->next= p->head;
		p->head->prev = newnode;
		p->head	= newnode;
		p->count++;
	}	
}

void mylist_push_back(LIST *p,NODE *newnode)
{
	if( p->head == NULL)
	{
		p->head=newnode;
		p->tail=newnode;
		p->count++;
	}
	else
	{
		newnode->prev=p->tail;
		p->tail->next=newnode;
		p->tail=newnode;
		p->count++;
	}	
	
}