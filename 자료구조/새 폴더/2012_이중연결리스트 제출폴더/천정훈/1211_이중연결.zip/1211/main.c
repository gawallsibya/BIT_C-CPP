#include"App.h"


void main()
{
	init();

	run();

	Exit();
}