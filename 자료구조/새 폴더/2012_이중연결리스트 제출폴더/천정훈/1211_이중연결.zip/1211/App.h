////app.h
#include"Manager.h"
//typedef struct App
//{
//	
//
	void init();
	void run();
	void Exit();
//
//
//	void menuprint();
//};
