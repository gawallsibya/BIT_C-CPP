//pcroom.h

#ifndef _PCROOM_H_
#define _PCROOM_H_

class CPerson;

class CPCRoom
{
public:
	void Visit(CPerson *p);
};

#endif /*_PCROOM_H_ */