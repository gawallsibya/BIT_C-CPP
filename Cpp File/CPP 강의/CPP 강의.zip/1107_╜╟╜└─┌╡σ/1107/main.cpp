//main.cpp

#include "std.h"
#include "app.h"

void main()
{
	CApp app;

	app.Init();
	app.Run();
	app.Exit();
}