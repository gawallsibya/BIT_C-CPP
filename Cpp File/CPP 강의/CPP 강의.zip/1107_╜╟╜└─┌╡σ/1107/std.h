//std.h

#include <iostream>
#include <time.h>
#include <conio.h>
#include <windows.h>
using namespace std;
