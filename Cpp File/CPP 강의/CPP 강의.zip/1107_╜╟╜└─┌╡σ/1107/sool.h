//sool.h

#ifndef _SOOL_H_
#define _SOOL_H_

class CPerson;

class CSool
{
public:
	void Visit(CPerson *p);
};

#endif /*_SOOL_H_ */