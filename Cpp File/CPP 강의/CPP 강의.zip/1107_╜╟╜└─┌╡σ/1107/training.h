//training.h

#ifndef _TRAINING_H_
#define _TRAINING_H_

class CPerson;

class CTraining
{
public:
	void Visit(CPerson *p);
};

#endif /*_TRAINING_H_ */