//library.h

#ifndef _LIBRARY_H_
#define _LIBRARY_H_

class CPerson;

class CLibrary
{
public:
	void Visit(CPerson *p);
};

#endif /*_LIBRARY_H_ */