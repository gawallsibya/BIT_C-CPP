#include <iostream>
using namespace std;
#include <conio.h>

#include "data.h"
#include "fun.h"