const int NAME_LEN	= 20;


enum { MAKE = 1, DEPOSIT, WITHDRAW, INQUIRE, EXIT };