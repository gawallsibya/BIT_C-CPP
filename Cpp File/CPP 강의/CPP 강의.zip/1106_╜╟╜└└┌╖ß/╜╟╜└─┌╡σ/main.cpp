// main.cpp

#include "std.h"
#include "app.h"

void main()
{

	App app;

	app.init();

	app.run();

	app.exit();

}