// std.h
#include <iostream>
#include <conio.h>
#include <time.h>
#include <stdio.h>
#include <windows.h>
using namespace std;

